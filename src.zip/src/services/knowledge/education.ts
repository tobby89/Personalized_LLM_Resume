export const educationInfo = {
  current: "I am pursuing a Master's degree in Computing Science at the University of Alberta from August 2023 to December 2024, with a GPA of 3.8/4.0.",
  previous: "I completed my Bachelor's in Computing Science, specializing in Graphics and Multimedia, from STMIK LIKMI Indonesia (2007-2011) with a GPA of 3.69/4.0."
};
