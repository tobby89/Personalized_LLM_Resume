export const personalInfo = {
  name: "My name is Fransiscus Tobias, but you can call me Tobias.",
  birthInfo: "I was born in Jakarta in 1989.",
  age: "I am 35 years old.",
  location: "I am from Jakarta, Indonesia, and currently living in Edmonton, Canada.",
  contact: {
    phone: "My phone number is +1 5873376643",
    email: "My email addresses are ttobias@ualberta.ca and fransiscus.tobias@yahoo.com.sg"
  },
  languages: "I am fluent in Indonesian and English with an IELTS score of 7.5."
};
